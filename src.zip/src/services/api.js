import axios from 'axios';


export async function fetchSERPData({ keyword, language_name, location_name }) {
    try {
      const response = await axios.post('http://localhost:3001/proxy/dataforseo', {
        keyword,
        language_name,
        location_name,
      });
      return response.data;
    } catch (error) {
      console.error('Error fetching SERP data:', error.response?.data || error.message);
      throw new Error('Failed to fetch SERP data');
    }
  }

export const fetchPageSpeedDataForURLs = async (urls) => {
  const results = [];
  for (const url of urls) {
    try {
      const response = await axios.get(`http://localhost:3001/proxy/pagespeed`, {
        params: { url },
      });
      results.push({ url, data: response.data });
    } catch (error) {
      console.error(`Error fetching PageSpeed data for ${url}:`, error);
    }
  }
  return results;
};